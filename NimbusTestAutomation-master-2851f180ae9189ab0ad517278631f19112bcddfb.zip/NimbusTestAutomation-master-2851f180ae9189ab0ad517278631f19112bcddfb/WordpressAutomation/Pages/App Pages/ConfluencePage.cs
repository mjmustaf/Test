﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Configuration;

namespace NimbusAutomation
{
   public class ConfluencePage
    {
       public static  string ValidationString;
       public static string winHandleBefore;


       public static void Login()
       {
           winHandleBefore = Driver.Instance.CurrentWindowHandle;
           Thread.Sleep(2000);
           Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
           Thread.Sleep(2000);
           Driver.Instance.Manage().Window.Maximize();

           var loginInput = Driver.Instance.FindElement(By.Id("os_username"));
           loginInput.SendKeys(ConfigurationManager.AppSettings["NimbusUser"]);


           var passwordInput = Driver.Instance.FindElement(By.Id("os_password"));
           passwordInput.SendKeys(ConfigurationManager.AppSettings["NimbusPassword"]);

           var loginBtn = Driver.Instance.FindElement(By.Id("loginButton"));
           loginBtn.Click();


       }

       public static string CreateBlankPage(String Summary)
       {
           Driver.Instance.FindElement(By.XPath("//li[4]/a/span")).Click();
           Driver.Instance.FindElement(By.XPath("//li[4]/a/span")).Click();
           Driver.Instance.FindElement(By.XPath("//div[14]/div/div[2]/button")).Click();
           var summaryTxtArea = Driver.Instance.FindElement(By.Id("content-title"));
           summaryTxtArea.SendKeys(Summary);
           Driver.Instance.FindElement(By.Id("rte-button-publish")).Click();
           Thread.Sleep(3000);
           Driver.Instance.FindElement(By.XPath("//div/a/img")).Click();
           ValidationString = Summary;
           return ValidationString;
       }


        public static Boolean   IsAbleToCreatePage()
        {

           
            var ab = Driver.Instance.FindElement(By.XPath("//div[5]/div/div[2]/div/div"));
            var cd = ab.FindElements(By.TagName("a"));
            var ef = cd.Skip(2).First().Text;
            Driver.Instance.Close();
            Driver.Instance.SwitchTo().Window(winHandleBefore);
            if (ef == ValidationString)
                 
            {
                return true;

            }
            else return false;
        }


     


    }
}
