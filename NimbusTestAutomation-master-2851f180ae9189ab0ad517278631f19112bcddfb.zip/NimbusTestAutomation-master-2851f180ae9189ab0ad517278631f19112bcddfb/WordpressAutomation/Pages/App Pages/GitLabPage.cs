﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Configuration;
namespace NimbusAutomation
{
    public class GitLabPage
    {
        public static string ValidationString;
        public static string winHandleBefore;

        public static void Login()
        {
            Thread.Sleep(2000);
            winHandleBefore = Driver.Instance.CurrentWindowHandle;
            Thread.Sleep(2000);
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            Thread.Sleep(2000);
            Driver.Instance.Manage().Window.Maximize();
            
            // exception handling required as sometimes user is logged in
            Driver.Instance.FindElement(By.LinkText("Sign in")).Click();
            var loginInput = Driver.Instance.FindElement(By.Id("username"));
            loginInput.SendKeys(ConfigurationManager.AppSettings["NimbusUser"]);


            var passwordInput = Driver.Instance.FindElement(By.Id("password"));
            passwordInput.SendKeys(ConfigurationManager.AppSettings["NimbusPassword"]);

            var loginBtn = Driver.Instance.FindElement(By.Name("button"));
            loginBtn.Click();
            
        
        }
        public static void CreateProject(string summary) 
        
        {
            Driver.Instance.FindElement(By.LinkText("New project")).Click();
            var projectPathArea = Driver.Instance.FindElement(By.Id("project_path"));
            projectPathArea.SendKeys(summary);
            Driver.Instance.FindElement(By.Id("project_visibility_level_20")).Click();
            Driver.Instance.FindElement(By.Name("commit")).Click();
           
        }

        public static Boolean IsAbleToCreateProject()
        {            
            var projectCreate = Driver.Instance.FindElements(By.XPath("//div[2]/div/div/div/div"));
           
            if (projectCreate.First().Text == "Project was successfully created.")
            {

                Driver.Instance.Close();
                Driver.Instance.SwitchTo().Window(winHandleBefore);
                return true;

            }
            else
                Driver.Instance.Close();
            Driver.Instance.SwitchTo().Window(winHandleBefore);
                return false;
        }

    }
}
