﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Configuration;

namespace NimbusAutomation
{
   public  class JenkinsPage
    {
        public static string ValidationString;
        public static string winHandleBefore;
        public static void Login()
        {
            Thread.Sleep(2000);
            winHandleBefore = Driver.Instance.CurrentWindowHandle;
            Thread.Sleep(2000);
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            Thread.Sleep(2000);
            Driver.Instance.Manage().Window.Maximize();
            Thread.Sleep(2000);
            Driver.Instance.FindElement(By.LinkText("Log in")).Click();



            var loginInput = Driver.Instance.FindElement(By.Name("j_username"));
            loginInput.SendKeys(ConfigurationManager.AppSettings["NimbusUser"]);

            var passwordInput = Driver.Instance.FindElement(By.Name("j_password"));
            passwordInput.SendKeys(ConfigurationManager.AppSettings["NimbusPassword"]);

            var loginBtn = Driver.Instance.FindElement(By.Id("yui-gen1-button"));
            loginBtn.Click();


        }


        public static void CreateBuild(string ItemName, string ProjectType)
        {

            Driver.Instance.FindElement(By.LinkText("New Item")).Click();
            var item = Driver.Instance.FindElement(By.Id("name"));
            item.SendKeys(ItemName);
            var items = Driver.Instance.FindElements(By.TagName("tbody"));
            var projItems = items.Skip(2).First();
            var projItemsName = projItems.FindElements(By.TagName("b"));
            foreach (var item1 in projItemsName)

            {
                if (item1.Text == ProjectType)
                {
                    item1.Click();
                }

            }

            Driver.Instance.FindElement(By.Id("ok-button")).Click();
            Thread.Sleep(3000);
            Driver.Instance.FindElement(By.Id("yui-gen14-button")).Click();
            Driver.Instance.FindElement(By.Id("yui-gen38-button")).Click();
            Driver.Instance.FindElement(By.LinkText("Build Now")).Click();

            var BuildHistory = Driver.Instance.FindElements(By.TagName("tbody"));
                BuildHistory.First().Click();
                Thread.Sleep(5000);
              //  Driver.Instance.FindElement(By.Id("menuSelector")).Click();
                //Driver.Instance.FindElement(By.LinkText("Console Output")).Click();
                 
            
        }

        public static Boolean IsAbleToCreateBuild()
        {
            //  Driver.Instance.FindElement(By.Id("menuSelector")).Click();
                //Driver.Instance.FindElement(By.LinkText("Console Output")).Click();
            Driver.Instance.Close();
            Driver.Instance.SwitchTo().Window(winHandleBefore);
            
                return true;
          
        }


    }
}
