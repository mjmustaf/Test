﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Configuration;
namespace NimbusAutomation
{
    public  class JiraPage
    {
        public static string winHandleBefore;
        public static void Login()
        {
            Thread.Sleep(2000);
            winHandleBefore = Driver.Instance.CurrentWindowHandle;
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            Thread.Sleep(2000);
            Driver.Instance.Manage().Window.Maximize();
            
            var loginInput = Driver.Instance.FindElement(By.Id("login-form-username"));
            loginInput.SendKeys(ConfigurationManager.AppSettings["NimbusUser"]);

                          
            var passwordInput = Driver.Instance.FindElement(By.Id("login-form-password"));
            passwordInput.SendKeys(ConfigurationManager.AppSettings["NimbusPassword"]);

            var loginBtn = Driver.Instance.FindElement(By.Id("login-form-submit"));
            loginBtn.Click();

           
        }

        public static void CreateIssue(String Summary)

        {
            Driver.Instance.FindElement(By.Id("create_link")).Click();
            var summaryTxtArea = Driver.Instance.FindElement(By.Id("summary"));
            summaryTxtArea.SendKeys(Summary);
            Driver.Instance.FindElement(By.Id("create-issue-submit")).Click();
            Thread.Sleep(2000);

        }


        public static Boolean IsAbleToCreateIssue()
        {

            Driver.Instance.Navigate().Refresh();
            var ab = Driver.Instance.FindElement(By.Id("fragactivitystream"));
            var cd = ab.FindElements(By.TagName("div"));
            var ef = cd.First();

            var gh = ef.FindElements(By.TagName("a"));

       ///var cd = ab.FindElement(By.TagName("div"))
       ///
            ///***start looking here 
      

           // var k = ab.FindElements(By.Id("activity-stream"));
         //   var activityStream = Driver.Instance.FindElements(By.Id("1"));
           // var a = Driver.Instance.FindElements(By.ClassName("blanket-container"));
            Driver.Instance.Close();
            Driver.Instance.SwitchTo().Window(winHandleBefore);
            return true;
           

        }
    }
}
