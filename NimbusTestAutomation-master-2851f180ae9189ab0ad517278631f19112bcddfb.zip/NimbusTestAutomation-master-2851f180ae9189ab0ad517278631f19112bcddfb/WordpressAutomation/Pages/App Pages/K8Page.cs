﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Configuration;

namespace NimbusAutomation
{
    public class K8Page
    {
        public static string winHandleBefore;
        public static void Login()
        {
            winHandleBefore = Driver.Instance.CurrentWindowHandle;
            Thread.Sleep(2000);
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            Thread.Sleep(2000);
            Driver.Instance.Manage().Window.Maximize();
            Thread.Sleep(2000);
        }

        public static bool IsValidK8Cluster()
        {
           var body = Driver.Instance.FindElements(By.TagName("body"));
           Driver.Instance.Close();
           Thread.Sleep(1000);
           Driver.Instance.SwitchTo().Window(winHandleBefore);
           return true;
        }
    }
}
