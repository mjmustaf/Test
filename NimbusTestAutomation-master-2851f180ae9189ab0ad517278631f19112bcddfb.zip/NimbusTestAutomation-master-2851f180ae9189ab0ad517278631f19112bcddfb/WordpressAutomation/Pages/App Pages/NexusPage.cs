﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Configuration;

namespace NimbusAutomation
{
   public class NexusPage
    {
       public static string winHandleBefore;
       public static void Login()
       {
           Thread.Sleep(2000);
           winHandleBefore = Driver.Instance.CurrentWindowHandle;
      
           Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
           Thread.Sleep(2000);
           Driver.Instance.Manage().Window.Maximize();
       }
       public static Boolean SnapshotExists() 
       {
           var archetype = Driver.Instance.FindElements(By.TagName("tr"));
           var k = archetype.Skip(2).First();
          
           if (k.Displayed == true)
           {
               Driver.Instance.Close();
               Driver.Instance.SwitchTo().Window(winHandleBefore);
               return true;
              
           }
           else
               Driver.Instance.Close();
           Driver.Instance.SwitchTo().Window(winHandleBefore);
            return false;
          
           
       }
    }
}
