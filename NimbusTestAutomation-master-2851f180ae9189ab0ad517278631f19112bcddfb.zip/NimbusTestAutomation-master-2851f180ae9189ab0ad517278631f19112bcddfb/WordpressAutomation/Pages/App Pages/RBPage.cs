﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;
using System.Configuration;

namespace NimbusAutomation
{
    public class RBPage
    {
        public static string ValidationString;
        public static string winHandleBefore;

        public static void Login()
        {
            winHandleBefore = Driver.Instance.CurrentWindowHandle;
            Thread.Sleep(2000);
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            Thread.Sleep(2000);
            Driver.Instance.Manage().Window.Maximize();
           
            var loginInput = Driver.Instance.FindElement(By.Id("id_username"));
            Thread.Sleep(3000);
            loginInput.SendKeys(ConfigurationManager.AppSettings["NimbusUser"]);


            var passwordInput = Driver.Instance.FindElement(By.Id("id_password"));
            passwordInput.SendKeys(ConfigurationManager.AppSettings["NimbusPassword"]);

            var loginBtn = Driver.Instance.FindElement(By.XPath("//div[3]/div/input"));
            loginBtn.Click();
            
        }



        public static string CreateReviewReq(String Summary)
        {
            Driver.Instance.FindElement(By.XPath("//div[2]/ul/li[2]/a")).Click();
            Thread.Sleep(2000);
            Driver.Instance.FindElement(By.XPath("//li[2]/div/span")).Click();

            Driver.Instance.FindElement(By.Id("files-only-create")).Click();

            Thread.Sleep(2000);
            Driver.Instance.FindElement(By.XPath("//a/div")).Click();

            var summaryTxtArea = Driver.Instance.FindElement(By.XPath("//form/input"));

            summaryTxtArea.SendKeys(Summary);

            Driver.Instance.FindElement(By.XPath("//label/a/div")).Click();
            Thread.Sleep(1000);

            var DescTxtArea = Driver.Instance.FindElement(By.XPath("//div[5]/pre"));
           // DescTxtArea.Click();
            Thread.Sleep(2000);
           
            DescTxtArea.SendKeys(Summary);

            Driver.Instance.FindElement(By.XPath("//div[2]/input")).Click();
            
          //  Driver.Instance.FindElement(By.Id("btn-draft-publish")).Click();
          //  Driver.Instance.FindElement(By.Id("//div/div[2]/ul/li[3]/a")).Click();

            ValidationString = Summary;
            Driver.Instance.Close();
            Driver.Instance.SwitchTo().Window(winHandleBefore);
            return ValidationString;
        }

        public static Boolean IsAbleToCreateProject()
        {
            var revReqCreate = Driver.Instance.FindElements(By.XPath("//a/div/span"));
            
            if (revReqCreate.First().Text == ValidationString)
            {
                Driver.Instance.Close();
                Driver.Instance.SwitchTo().Window(winHandleBefore);
                return true;
            }
            else
                Driver.Instance.Close();
            Driver.Instance.SwitchTo().Window(winHandleBefore);
                return false;
        }

    }
}
