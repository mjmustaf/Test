﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System.Threading;



namespace NimbusAutomation

{
   

    public  class InfoPass
    {

        public static   void CheckAppointment() {

            
            //  Driver.Instance.FindElement(By.Id("Create-button")).Click();

            Driver.Instance.FindElement(By.Id("create-button")).Click();

            Driver.Instance.FindElement(By.Id("appointments_appointment_zip")).Click();

            Driver.Instance.FindElement(By.Id("appointments_appointment_zip")).SendKeys("91320");

            Driver.Instance.FindElement(By.CssSelector("#field_office_query > span")).Click();

            Driver.Instance.FindElement(By.Id("create-appointment")).Click();

            var a = Driver.Instance.FindElements(By.Id("mod-calendar_component-1"));

            foreach (var item in a)
            {

                string msg = item.Text;
                string hardmsg = "Currently, there are no available appointments. Please check again tomorrow.";


                Assert.IsTrue(msg.Contains(hardmsg) );

                //Console.WriteLine(msg);
               // Console.WriteLine(hardmsg);




            }


            Thread.Sleep(3000);




        }



    }
}
