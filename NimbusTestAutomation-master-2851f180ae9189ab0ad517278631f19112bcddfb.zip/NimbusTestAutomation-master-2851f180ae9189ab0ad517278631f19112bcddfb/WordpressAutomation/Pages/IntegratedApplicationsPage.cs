﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Diagnostics;

namespace NimbusAutomation
{
   public class IntegratedApplicationsPage
    {
       public  static int retry = 0;
      public static string server_Url= "";
      

       public static string ClickApp(string Team_Name, string serverName)

       {
           var listOFApps = Driver.Instance.FindElement(By.ClassName("md-tabs-content"));
           var listOfApps1 = listOFApps.FindElements(By.TagName("li"));
           foreach (var item in listOfApps1)
           {
              
               if (item.Text == serverName)
               {
                    server_Url = item.FindElement(By.TagName("a")).GetAttribute("href");
                    item.Click();// click  the application icon
                  
               }
               
           }
           return server_Url;
       
       }
        public static void CheckIntegratedApps(string Team_Name)
        {
            SelectTeam(Team_Name);

            //get list of all integrated apps
            var listOFApps = Driver.Instance.FindElement(By.ClassName("md-tabs-content"));

            // var listOfApps11 = Driver.Instance.FindElement(By.ClassName("li-integ-app"));
             var listOfApps1 = listOFApps.FindElements(By.TagName("li"));
            //var listOfApps1 = listOFApps.FindElements(By.ClassName("li-integ-app"));
            List<string> listOfApps2 = new List<string>();
            List<string> listOfFailedApps = new List<string>();
            foreach (var item in listOfApps1)
            {


                // Except Maven, we check the "div" tag for each app to find if the error image is diaplayed
                //  if (item.Text == "Nexus : Maven Snapshot" || item.Text == "Nexus : Maven Release")
                if (item.Text == "")
                {
                }
                else
                {
                    listOfApps2.Add(item.Text); // add if not null

                    try
                    {
                        var integFailedIcon = item.FindElement(By.TagName("div"));
                        if (integFailedIcon.Displayed == true)
                        {
                            listOfFailedApps.Add(item.Text);
                        }

                    }

                    catch
                    {

                    }








                    //   listOfApps1[6].FindElements(By.ClassName("li-integ-app-failed"))
                    //var errorImg = item.FindElement(By.TagName("div"));
                    //if (errorImg.Displayed == true)
                    //{

                    //Click the Home Page to get the list refreshed and see if the apps are available in OK state
                    //             retry = retry + 1;
                      //              if (retry == 2)
                        //            {
                                        // Assert.Fail((item.Text).ToUpper() + " SET UP FAILED with " + retry + "retries " + ", please check");
                                      //  Console.WriteLine(String.Join(",", listOfFailedApps.ToArray()));// + " SET UP FAILED with " + retry + "retries " + ", please check");
                          //              break;
                            //        }
                          //CheckIntegratedApps(Team_Name);*/

                      


                }//esle

            }// for each    
        
           var IntegratedApps = new List<string> { "Kubernetes Cluster",
                                  "Jira",
                                  "Confluence",
                                  "GitLab",
                                 "Jenkins",
                                  "SonarQube",
                                  "Nexus : Maven Snapshot",
                                  "Nexus : Maven Release" };

          if (listOfApps2.Count != IntegratedApps.Count)
           {
                retry = retry + 1;
                IntegratedApplicationsPage.CheckIntegratedApps(Team_Name);
                if (retry == 2)
                Assert.Fail("Missing application Total number of applications Integrated "+listOfApps2.Count+ " "+  "With Retries  "+retry);
                

            }
          if (listOfFailedApps.Count>0)
            Console.WriteLine(String.Join(",", listOfFailedApps.ToArray()));



       }// end method

       private static void SelectTeam(string Team_Name)
       {
           Thread.Sleep(3000);
        //   Driver.Instance.FindElement(By.XPath("//a/button")).Click();
           var listofTeams = Driver.Instance.FindElements(By.XPath("//section[@id='main-section']/md-sidenav/md-content/div/ul[2]/li"));
           foreach (var item1 in listofTeams)
           {
               if (item1.Text == Team_Name)
               {
                   item1.Click();
                   Thread.Sleep(3000); // sleep for 3 Seconds


               }

           }
       }

       public static void Goto(string Team_Name,string serverName)
       {
           SelectTeam(Team_Name);
           ClickApp(Team_Name, serverName);
         
       }

    } // end class
}// end namespace
