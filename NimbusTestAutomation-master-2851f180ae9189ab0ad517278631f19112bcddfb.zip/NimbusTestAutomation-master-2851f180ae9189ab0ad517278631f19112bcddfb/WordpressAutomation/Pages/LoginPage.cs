﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.IE;
using System.Threading;
using NimbusAutomation;
using System.Configuration;



namespace NimbusAutomation
{
    public class LoginPage
    {
        public static void GoTo()
        {

            Driver.Instance.Navigate().GoToUrl(ConfigurationManager.AppSettings["URL"]);
        }

        public static LoginCommand LoginAs(string userName)
        {
            return new LoginCommand(userName);
        }
    }

    public class LoginCommand
    {
        private readonly string userName;
        private string password;

        public LoginCommand(string userName)
        {
            this.userName = userName;
        }

        public LoginCommand WithPassword(string password)
        {
            this.password = password;
            return this;
        }

        public void Login()
        {

            try

            {
                var loginInput = Driver.Instance.FindElement(By.Id("usernameInput"));
                var passwordInput = Driver.Instance.FindElement(By.Id("passwordInput"));
                var loginBtn = Driver.Instance.FindElement(By.TagName("span"));
                loginInput.SendKeys(userName);
                passwordInput.SendKeys(password);
                Thread.Sleep(5000);
                loginBtn.Click();
            }

            catch
            {

                var loginBtn = Driver.Instance.FindElement(By.XPath("//div[@id='login-section']/div/md-content/div/div/a/button"));
                loginBtn.Click();
            }


        }
    }

}       

            





    
    

