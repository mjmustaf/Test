﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.RegularExpressions;




namespace NimbusAutomation

{
    public class MainPage:Nimbusutilities
    {
        public static void CreateTeam()
        {
            // Click the CreateNew Team Button on Main page
            Driver.Instance.FindElement(By.XPath("//div[2]/div/button")).Click();
          

        }


        public static void Goto( string Team_Name, string App)
        {
            IntegratedApplicationsPage.Goto(Team_Name, App);


        }



        public static CreateTeamCommand TeamName(string title)
        {
            return new CreateTeamCommand(title);
        }

        public static void CloseCreatingTeamWindow()
        {
             // Click the close button while the team is being Created
            Driver.Instance.FindElement(By.XPath("//md-dialog/div/div[2]/div/button")).Click();

        }

        public static bool IsInEditMode()
        {
            return Driver.Instance.FindElement(By.Id("icon-edit-pages")) != null;
        }

        public static string Title
        {
            get
            {
                var title = Driver.Instance.FindElement(By.Id("title"));
                if (title != null)
                    return title.GetAttribute("value");
                return string.Empty;
            }
        }

        public static void FindTeam()
        {
            throw new NotImplementedException();
        }

        public static void RecursiveDelete(string teamPattern)
        {

            var listofTeams = Driver.Instance.FindElements(By.XPath("//section[@id='main-section']/md-sidenav/md-content/div/ul[2]/li"));
            string sPattern = teamPattern;

            try
            {

          
                 foreach (var item in listofTeams)
                 {



                if (Regex.IsMatch(item.Text, sPattern)) {
                
                item.Click();
                Thread.Sleep(5000);
                 Driver.Instance.FindElement(By.XPath("//md-tab[4]/md-tab-label")).Click();
                Driver.Instance.FindElement(By.XPath("//section[5]/div/div/button/span")).Click();
                Driver.Instance.FindElement(By.XPath("//div/button[2]/span")).Click();
                Thread.Sleep(3000);
                Driver.Instance.FindElement(By.XPath("//li/a/button")).Click();
                Thread.Sleep(3000);
                RecursiveDelete(teamPattern);
                 }
                }

            }
            catch (Exception)
            {

                throw;
              
              
            }



        }


        public  static void DeleteTeam() // only delete the stack of teams thats pattern with "AUTO"
        {

                       RecursiveDelete("AUTO");

                    
            
        }

        public static void VerifyCreatedTeamStatus(string Team_Name)
        {
            //Read all the teamNames from the left pane and click on the teamname

             var listofTeams = Driver.Instance.FindElements(By.XPath("//section[@id='main-section']/md-sidenav/md-content/div/ul[2]/li"));
            foreach (var item in listofTeams)
                {
                    if (item.Text == Team_Name)
                    {
                        item.Click();
                    }
                                 
                }

            
            var getJobStatus = Driver.Instance.FindElement(By.ClassName("md-tabs-content"));
            var getJobStatus1 = getJobStatus.FindElement(By.ClassName("ng-binding"));
            Thread.Sleep(3000);
         /// code to wait untill the Prvision status is vaible, sometimes they come fast
            while ((getJobStatus1.Text == "ANSIBLE_WAITING") | (getJobStatus1.Text == "ANSIBLE_RUNNING") |( getJobStatus1.Text == "ANSIBLE_PENDING")
                      | (getJobStatus1.Text == "ANSIBLE_CREATED") | (getJobStatus1.Text == "INTEGRATING"))
            {

                if (getJobStatus1.Text == "")
                {
                    System.Console.WriteLine("Team Create was Sucessful");

                    break;
                }
                 
                Driver.Instance.FindElement(By.XPath("//span[3]/button")).Click(); // click the refresh spinner
                    Thread.Sleep(1000);
                    if( (getJobStatus1.Text == "FAILED") | (getJobStatus1.Text == "ANSIBLE_CANCELED"))
                      {
                          Assert.Fail("Job Failed due to  " + getJobStatus1.Text);
                        
                      }

                    
            }
       
        }
    }

    public class CreateTeamCommand
    {
        private readonly string title;
        private string desc, costcenter, reponame;
        

        public CreateTeamCommand(string title)
        {
            this.title = title;
        }

        public CreateTeamCommand WithDesc(string desc)
        {
            this.desc = desc;
            return this;
        }


        public CreateTeamCommand WithCostCenter(string costcenter)
        {
            this.costcenter = costcenter;
            return this;
        }

        public CreateTeamCommand WithRepo(string reponame)
        {
            this.reponame = reponame;
            return this;
        }



        public void Create()
        {
           // Perform the Operation on Create new team 
            Driver.Instance.FindElement(By.Id("teamName")).SendKeys(title);
            Driver.Instance.FindElement(By.XPath("//label[3]/input")).SendKeys(desc);
            Driver.Instance.FindElement(By.XPath("//label[4]/input")).SendKeys(costcenter);
            Driver.Instance.FindElement(By.XPath("//td[2]/md-checkbox")).Click(); // Click Nuget repo
            Driver.Instance.FindElement(By.XPath("//tr[2]/td[2]/md-checkbox")).Click();// Click Py Repo
            Driver.Instance.FindElement(By.XPath("//tr[2]/td/md-checkbox")).Click(); // click Node/PM
            Driver.Instance.FindElement(By.Id("dotnetslave")).Click();


            Driver.Instance.FindElement(By.XPath("//button[2]")).Click();

            
      
           
        }


    }
}
