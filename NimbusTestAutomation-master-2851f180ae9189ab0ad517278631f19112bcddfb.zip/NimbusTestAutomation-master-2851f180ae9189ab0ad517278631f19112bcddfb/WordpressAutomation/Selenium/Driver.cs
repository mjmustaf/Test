﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
using System.Configuration;




namespace NimbusAutomation
{
    public class Driver
    {
        public static IWebDriver Instance { get; set; }
      
        
        public static void Initialize()
        {

            var browser = ConfigurationManager.AppSettings.Get("Browser");
            
            switch (browser)
           {
               case "IE":
               Instance = new InternetExplorerDriver(ConfigurationManager.AppSettings["DRIVER_PATH"]);
               break;
         
               case "CHROME":
               Instance = new ChromeDriver();
               break;

               case "FIREFOX":
               Instance = new FirefoxDriver();
               break;

               case "":
               Instance = new InternetExplorerDriver();
               Instance = new ChromeDriver();

               break;

           }

           Instance.Manage().Window.Maximize();

            Instance.Manage().Timeouts().ImplicitWait = (TimeSpan.FromSeconds(30));
        }

        public static void Close()
        {
        //   Instance.Close();
        }
    }
}