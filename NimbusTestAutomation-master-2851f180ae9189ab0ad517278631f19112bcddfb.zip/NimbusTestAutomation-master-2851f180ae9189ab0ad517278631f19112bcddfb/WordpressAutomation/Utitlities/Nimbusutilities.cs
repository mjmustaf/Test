﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NimbusAutomation;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;



namespace NimbusAutomation
{
   public class Nimbusutilities
    {
       
          public static String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMdd_HHmmss_ff");
        }

          public static String GetTimestampGit(DateTime value)
          {
              return value.ToString("yyyyMMddHHmmssff");
          }

        public static  List<String> GetRegex(List<String> text, string pattern)

        {
         

            var  pattern1 = @pattern;
            Regex rx = new Regex(pattern1);

            List<String> matchlist = text.Where(i => rx.IsMatch(i)).ToList();

            foreach (var item in matchlist)
            {
                Console.WriteLine(item);
            }

           

            return matchlist;
           
        }

        

    }
}
