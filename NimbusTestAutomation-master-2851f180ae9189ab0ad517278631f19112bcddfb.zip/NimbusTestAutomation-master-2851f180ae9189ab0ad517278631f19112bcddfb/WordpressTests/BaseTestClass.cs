﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NimbusAutomation;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NimbusTests
{
    [TestClass]
    public class BaseTestClass:Nimbusutilities
    {
        [TestInitialize]
        public void Init()
        {
    
            Driver.Initialize();
            LoginPage.GoTo();
           LoginPage.LoginAs(ConfigurationManager.AppSettings["NimbusUser"])
                      .WithPassword(ConfigurationManager.AppSettings["NimbusPassword"])
                       .Login();


            
         }
      [TestCleanup]
       public void Cleanup()
        {
           Driver.Close();

        }
        
    }
}
