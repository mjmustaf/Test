﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NimbusAutomation;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace NimbusTests.Smoke_Tests.AppValidationTests
{
    [TestClass]
   public class ValidateApps:BaseTestClass
    {

       [TestMethod]
      public void ValidateJira()
      {

          //MainPage.CreateTeam();
          MainPage.Goto(" AUTO_20160121_111135_38", "Jira");
                    
          JiraPage.Login();
          JiraPage.CreateIssue("Jira QA Automation Validation_"+CreateTeam.Team_Name);
          Assert.IsTrue(JiraPage.IsAbleToCreateIssue(), "FAiled to create issue in Jira");
              
          
      }
         [TestMethod]
       public void ValidateConfluence()
       {

           MainPage.Goto(" AUTO_20160121_111135_38", "Confluence");

           ConfluencePage.Login();
           ConfluencePage.CreateBlankPage("Confluence QA Automation Validation_" + CreateTeam.Team_Name);
           Assert.IsTrue(ConfluencePage.IsAbleToCreatePage(), "FAiled to create Page in confluence");

       }


         [TestMethod]
         public void ValidateK8()
         {

             MainPage.Goto(" AUTO_20160121_111135_38", "Kubernetes Cluster");
            // K8Page.Login();             
             //Assert.IsTrue(K8Page.IsValidK8Cluster(), "FAiled to create Kubernetes cluster");

         }



         [TestMethod]
         public void ValidateGitLab()
         {

             MainPage.Goto(" AUTO_20160121_111135_38", "GitLab");
            GitLabPage.Login();
        //    GitLabPage.CreateProject("GitlabQAAutomationValidation" + CreateTeam.Team_Name_GIT);
            Assert.IsTrue(GitLabPage.IsAbleToCreateProject(), "Failed to create Gitlab Project");

         }

         [TestMethod]
         public void ValidateJenkins()
         {

             MainPage.Goto(" AUTO_20160121_111135_38", "Jenkins");
             JenkinsPage.Login();
             JenkinsPage.CreateBuild("Jenkins QA Automation Validation_" + CreateTeam.Team_Name,"Freestyle project");
             Assert.IsTrue(JenkinsPage.IsAbleToCreateBuild(), "Failed to create Build in Jenkins");

         }

        [TestMethod]
         public void ValidateRB()
         {

             MainPage.Goto(" AUTO_20160121_111135_38", "Reviewboard");
             RBPage.Login();
             RBPage.CreateReviewReq("Review Board  QA Automation Validation_" + CreateTeam.Team_Name);
             //Assert.IsTrue(RBPage.IsAbleToCreateBuild(), "Failed to create Build in Jenkins");

          }

        [TestMethod]
        public void ValidateMavenSnapShot()
        {

            MainPage.Goto(" AUTO_20160121_111135_38", "Nexus : Maven Snapshot");
            NexusPage.Login();
            Assert.IsTrue(NexusPage.SnapshotExists(), "Failed to Create Maven SnapShot");

          
        }


        [TestMethod]
        public void ValidateMavenRelease()
        {
            MainPage.Goto(" AUTO_20160121_111135_38", "Nexus : Maven Release");
            NexusPage.Login();
            Assert.IsTrue(NexusPage.SnapshotExists(), "Failed to create Build in Maven Release");

        }


        [TestMethod]
        public void ValidateAllApps()
        {
                       
            ValidateConfluence();
            ValidateGitLab();
            ValidateJenkins();
         //   ValidateMavenSnapShot();
            ValidateMavenRelease();
            ValidateJira();
            ValidateK8();



        }



    }
}
