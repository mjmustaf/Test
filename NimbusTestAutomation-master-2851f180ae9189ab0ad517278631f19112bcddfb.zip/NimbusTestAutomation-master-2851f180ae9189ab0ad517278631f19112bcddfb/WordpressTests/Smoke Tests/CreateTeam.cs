﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NimbusAutomation;


namespace NimbusTests
{
    [TestClass]
    public class CreateTeam:BaseTestClass
    {
      public static string Team_Name = (" Auto_" + Nimbusutilities.GetTimestamp(DateTime.Now)).ToUpper();
       public static string Team_Name_GIT = ("Auto" + Nimbusutilities.GetTimestampGit(DateTime.Now)).ToUpper();

       //public static string Team_Name = " AUTO_20180814_112941_38";
        //public static string Team_Name = (" TestNewJenkinsImg12").ToUpper();
        [TestMethod]
        public void Create_Team()
        {
            
         MainPage.CreateTeam();
            MainPage.TeamName(Team_Name)
                      .WithDesc("TeamCreate Desc")
                      .WithCostCenter("12504")
                    .Create();

          MainPage.CloseCreatingTeamWindow();

            MainPage.VerifyCreatedTeamStatus(Team_Name);

        
          }

        [TestMethod]
        public void DeleteCreatedTeam()

        {

            MainPage.DeleteTeam();


        }

        [TestMethod]
        public void CheckApt()

        {

            InfoPass.CheckAppointment();


        }


    }
}
