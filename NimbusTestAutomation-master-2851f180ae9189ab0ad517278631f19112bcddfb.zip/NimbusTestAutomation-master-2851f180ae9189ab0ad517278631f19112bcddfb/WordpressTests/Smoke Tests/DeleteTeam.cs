﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NimbusAutomation;

namespace NimbusTests
{  
  [TestClass]
    public class DeleteTeam:Nimbusutilities
                            
    {
      [TestMethod]
        public void DeleteCreatedTeam()

        {
            
            MainPage.DeleteTeam();

            
        }

    }
}
