﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NimbusAutomation;

namespace NimbusTests
{
        [TestClass]
   public class IntegratedApplications:BaseTestClass
    {
            [TestMethod]
            public  void ValidateIntegratedApps( )
            {
                
                CreateTeam CT = new CreateTeam();
               CT.Create_Team();

               IntegratedApplicationsPage.CheckIntegratedApps(CreateTeam.Team_Name);

              //  IntegratedApplicationsPage
                //    .Goto(CreateTeam.Team_Name,"Confluence");
                
                   //.Login();
                                           
            }
           
       
            

    }
}
