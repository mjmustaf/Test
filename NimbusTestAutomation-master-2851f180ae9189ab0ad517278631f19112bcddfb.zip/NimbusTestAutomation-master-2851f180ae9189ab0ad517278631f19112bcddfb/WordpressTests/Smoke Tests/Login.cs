﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NimbusAutomation;

using System.Configuration;

namespace NimbusTests
{

    [TestClass]
    public class LoginTests
    {
        [TestInitialize]
        public void Init()
        {
            Driver.Initialize();
        }


        

            [TestMethod]
        public void Login()
        {
            LoginPage.GoTo();

           
         LoginPage.LoginAs(ConfigurationManager.AppSettings["NimbusUser"])
                    .WithPassword(ConfigurationManager.AppSettings["NimbusPassword"])
                  .Login();


          
        }




    



        [TestCleanup]
        public void Cleanup()
        {
            Driver.Close();
        }
    }
}
