﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace NimbusTests.Utitlities
{
    [TestClass]
    public class UnitTest1
    {
       // [TestMethod]
       /* public void TestRegEx()
        {
            List<string> files = new List<string>();
            files.Add("auto1");
            files.Add(" AUTO");
            files.Add("aaa");
            Nimbusutilities NM = new Nimbusutilities();

            //NM.GetRegex(files, " AUTO"); */
            

        }
    
}
